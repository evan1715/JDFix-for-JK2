//gamedefs.h
#ifndef GAMEDEFS_H
#define GAMEDEFS_H


#endif
