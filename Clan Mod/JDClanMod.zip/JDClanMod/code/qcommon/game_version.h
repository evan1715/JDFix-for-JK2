// Copyright (C) 2000-2002 Raven Software, Inc.
//

// Current version of the multi player game

#define	Q3_VERSION		"JK2MP: v1.03a"

//end
