Hello!
All you have to do to give me credit is put this 'Code' folder inside your own mod folder.

To find any code I put in these files, just search //JediDog

Questions?
http://jedidog.freeforums.org/


Credits for cbuf_execute and turret fix go to ouned