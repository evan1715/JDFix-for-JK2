#ifndef __con_text_h
#define __con_text_h


/********************************************************************************

Text printed at console

********************************************************************************/


#define PACKAGE_CON_TEXT		0x03

enum
{
	CON_TEXT_DUMP_USAGE = 0x0300
};


#endif // __con_text_h
