#ifndef __str_server_h
#define __str_server_h


/********************************************************************************

Server strings

********************************************************************************/


#define PACKAGE_STR_SERVER		0x01

enum
{
	STR_SERVER_SERVER_NOT_RUNNING = 0x0100
};


#endif // __str_server_h
