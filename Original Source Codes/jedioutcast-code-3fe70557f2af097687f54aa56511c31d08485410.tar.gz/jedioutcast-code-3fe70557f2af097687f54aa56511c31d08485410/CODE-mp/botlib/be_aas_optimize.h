
/*****************************************************************************
 * name:		be_aas_optimize.h
 *
 * desc:		AAS
 *
 * $Archive: /source/code/botlib/be_aas_optimize.h $
 * $Author: Mrelusive $ 
 * $Revision: 2 $
 * $Modtime: 10/05/99 3:32p $
 * $Date: 10/05/99 3:42p $
 *
 *****************************************************************************/

void AAS_Optimize(void);

