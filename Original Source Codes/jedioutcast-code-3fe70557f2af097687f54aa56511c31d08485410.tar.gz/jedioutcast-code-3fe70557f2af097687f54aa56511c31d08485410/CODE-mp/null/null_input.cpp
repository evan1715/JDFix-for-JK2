#include "../client/client.h"

void IN_Init( void ) {
}

void IN_Frame (void) {
}

void IN_Shutdown( void ) {
}

void Sys_SendKeyEvents (void) {
}

