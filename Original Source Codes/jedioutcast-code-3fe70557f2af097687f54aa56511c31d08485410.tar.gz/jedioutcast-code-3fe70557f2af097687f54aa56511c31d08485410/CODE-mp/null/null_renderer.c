/* Null renderer functions */

void RB_StageIteratorGeneric(void)
{
}

void RB_StageIteratorSky(void)
{
}

void RB_StageIteratorVertexLitTexture(void)
{
}

void RB_StageIteratorLightmappedMultitexture(void)
{
}

void R_SyncRenderThread(void)
{
}
