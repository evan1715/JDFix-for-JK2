
#include "../qcommon/vm_local.h"

void VM_Compile( vm_t *vm, vmHeader_t *header ) {}
int	VM_CallCompiled( vm_t *vm, int *args ) {}



